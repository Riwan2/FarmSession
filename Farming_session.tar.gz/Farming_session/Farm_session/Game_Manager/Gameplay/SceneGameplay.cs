﻿using System;
using System.Collections.Generic;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;

namespace Farming_session
{
	public class SceneGameplay : Scene
	{
		
		public Hero myCharacter;
		public static int GameplayScale { get; set; } = 3;
		//GameFile
		public GameFile gameFile;
		//Map
		public TileMap map;
		public MapFile mapFile;
		public bool mapSaving;
		//TileObject
		public static List<TileObject> TileObjectList;
		public static Vector2 WheatTime { get; private set; } = new Vector2(20, 45);
		//BuildMode
		BuildMode buildMode;
		//KeysBoard
		private KeyboardState newKeyboardState;
		private KeyboardState oldKeyboardState;
		//Mouse
		private MouseState newMouseState;
		private MouseState oldMouseState;
		private Point mousePos;
		//GUI
		private GameplayOutput gameplayOutput;
		public double Fps_Count;
		//Shader
		RenderTarget2D mainTarget;
		public LightShader lightShaderManager;
		bool shaderActivated;
		//TimeManager
		public TimeManager timeManager;
		private bool groundDryed;
		//ChangeMap
		public ChangeMap changeMap;
		//Camera
		public Camera camera;
		//ParticleEngine
		ParticleEngine particleEngine;
		//SpellManager
		public SpellManager spellManager;

		public SceneGameplay(MainGame pMainGame) : base(pMainGame)
		{
			
		}

		public override void Load()
		{
			Rectangle Screen = mainGame.Window.ClientBounds;

			//GameFile
			gameFile = new GameFile(this);
			gameFile.ImportingGameData();

			//ChangeMap
			MapData.PopulateData();
			changeMap = new ChangeMap(this, mainGame, MapData.Data[gameFile.CurrentMap]);

			//Hero set
			myCharacter = new Hero(mainGame.Content.Load<Texture2D>("Player/HeroWalk_down"),
								   mainGame.Content.Load<Texture2D>("PlayerSelector"),
								   16, 48, 16, 16, 0.4f, GameplayScale, this,
								   mainGame.Content.Load<Texture2D>("Player/MageBaton"));
			myCharacter.Position = new Vector2(Screen.Width / 3.15f, Screen.Height / 2);

			myCharacter.Animation["walk_left"] = mainGame.Content.Load<Texture2D>("Player/HeroWalk_left");
			myCharacter.Animation["walk_up"] = mainGame.Content.Load<Texture2D>("Player/HeroWalk_up");
			myCharacter.Animation["walk_right"] = mainGame.Content.Load<Texture2D>("Player/HeroWalk_right");
			myCharacter.Animation["walk_down"] = mainGame.Content.Load<Texture2D>("Player/HeroWalk_down");
			//Baton
			myCharacter.Animation["walk_left_baton"] = mainGame.Content.Load<Texture2D>("Player/HeroWalk_left_baton");
			myCharacter.Animation["walk_up_baton"] = mainGame.Content.Load<Texture2D>("Player/HeroWalk_up_baton");
			myCharacter.Animation["walk_right_baton"] = mainGame.Content.Load<Texture2D>("Player/HeroWalk_right_baton");
			myCharacter.Animation["walk_down_baton"] = mainGame.Content.Load<Texture2D>("Player/HeroWalk_down_baton");

			//TimeManager
			timeManager = new TimeManager(13);
			groundDryed = false;

			//Camera
			camera = new Camera(mainGame.GraphicsDevice.Viewport, myCharacter.Position);

			//mapFile loading
			mapFile = new MapFile();

			//GUI
			gameplayOutput = new GameplayOutput(new Vector2(Screen.Width / 2, Screen.Height / 2), mainGame, mapFile, myCharacter, this);

			if (SceneMenu.LoadSaves) {
				mapFile.LoadingMap();
				mapFile.SetMapFile();

				map = new TileMap(mainGame, changeMap.CurrentMap.FileName);
				//map loading
				map.LoadMap();
				mapSaving = false;

				myCharacter.Position = gameFile.HeroPosition;
				//Camera
				camera.CameraFix = changeMap.CurrentMap.CameraFix;
				camera.Position = new Vector2(-MainGame.ScreenWidth, -MainGame.ScreenHeight);

				if (camera.CameraFix) {
					camera.Position = changeMap.CurrentMap.CameraPosition;
				} else {
					if (myCharacter.Position.Y >= (TileMap.MapHeight * TileMap.TileHeight) - MainGame.ScreenHeight / 2) {
						camera.Position = new Vector2(camera.Position.X, -(TileMap.MapHeight * TileMap.TileHeight -
						                                                  MainGame.ScreenHeight) - MainGame.ScreenHeight);
						Console.WriteLine((TileMap.MapHeight * TileMap.TileHeight) - MainGame.ScreenHeight / 2);
					}
					if (myCharacter.Position.X >= (TileMap.MapWidth * TileMap.TileWidth) - MainGame.ScreenWidth / 2) {
						camera.Position = new Vector2(-(TileMap.MapWidth * TileMap.TileWidth -
						                                MainGame.ScreenWidth) - MainGame.ScreenWidth, camera.Position.Y);
					}
				}
				//Inventory + time
				timeManager.SetHour(gameFile.CurrentTime);
				gameFile.GetInventory(gameplayOutput.InventoryManager);
				gameplayOutput.overlayInventory.Populate();
			} else {
				map = new TileMap(mainGame, "level1");
				camera.Position = new Vector2(-MainGame.ScreenWidth, -MainGame.ScreenHeight);
				//map loading
				map.LoadMap();
				mapSaving = false;
			}

			Console.WriteLine(camera.Position);

			//Keyboard
			oldKeyboardState = Keyboard.GetState();
			//Mouse
			oldMouseState = Mouse.GetState();

			//Shader
			if (gameFile.CurrentMap == "house") {
				ShaderSet(false);
			} else {
				ShaderSet(true);
			}

			//TileObject
			CropData.PopulateData();
			TileObjectRecup();

			//buildMode set
			buildMode = new BuildMode(mainGame.Content.Load<Texture2D>("Selector"),
									  mainGame.Content.Load<Texture2D>("tileset"), this);

			//ParticleEngine
			particleEngine = new ParticleEngine(mainGame, myCharacter.Position, myCharacter);
			//particleEngine.PlayerFootPrint = true;

			//Spell
			spellManager = new SpellManager();
			PassivSpellData.PopulateData(mainGame.Content);

			base.Load();
		}

		public override void Unload()
		{

			base.Unload();
		}

		public override void Update(GameTime gameTime)
		{
			newKeyboardState = Keyboard.GetState();
			newMouseState = Mouse.GetState();
			mousePos = newMouseState.Position;

			//GUI
			gameplayOutput.Update(gameTime, newKeyboardState, oldKeyboardState, newMouseState, oldMouseState, mousePos);

			if (!gameplayOutput.OverlayActive) {

				if (newKeyboardState.IsKeyDown(Keys.Enter) && oldKeyboardState.IsKeyUp(Keys.Enter)) {
					mapSaving = true;
					mapFile.SavingMap();
					Console.WriteLine("saving the game");
					mapSaving = false;
				}

				if (!mapSaving && buildMode.BuildModeActivated) {
					buildMode.BuildUpdate(gameTime, newKeyboardState, oldKeyboardState);
					myCharacter.IsInvisible = true;
				} else {
					myCharacter.IsInvisible = false;
				}

				base.Update(gameTime);

				//BuildMode
				if (newKeyboardState.IsKeyDown(Keys.B) && oldKeyboardState.IsKeyUp(Keys.B)) {

					buildMode.BuildModeActivated = !buildMode.BuildModeActivated;
					buildMode.selector.IsInvisible = !buildMode.selector.IsInvisible;
				}

				//TileObject
				for (int i = 0; i < TileObjectList.Count; i++) {
					if (TileObjectList[i].Type == TileObject.eType.Crop) {
						Crop a = (Crop)TileObjectList[i];
						a.Update(gameTime);
					}
					if (TileObjectList[i].Delete == true) {
						TileObjectList.Remove(TileObjectList[i]);
						i--;
					}
				}

				//Character
				myCharacter.Update(gameTime, newKeyboardState, oldKeyboardState, newMouseState, oldMouseState, mousePos);
				//LightShader
				lightShaderManager.AmbientColor(timeManager.BackgroundValue);
				//Camera
				camera.UpdateCamera(mainGame.GraphicsDevice.Viewport, myCharacter);
				//TimeManager
				timeManager.Update(gameTime);
				//ParticleEngine
				particleEngine.Update(gameTime);
				//SpellManager
				spellManager.Update(gameTime);

				if (timeManager.CurrentHour == 0 && !groundDryed) {
					groundDryed = true;
					DryGround();
					Console.WriteLine("ground dryed");
				} else if (timeManager.CurrentHour != 0) {
					groundDryed = false;
				}

				map.Update(gameTime);

			}

			oldKeyboardState = Keyboard.GetState();
			oldMouseState = Mouse.GetState();
		}

		public override void Draw(GameTime gameTime)
		{
			if (!mapSaving) {

				mainGame.GraphicsDevice.SetRenderTarget(mainTarget);
				mainGame.spriteBatch.Begin(SpriteSortMode.Deferred, BlendState.AlphaBlend, SamplerState.PointClamp,
										   null, null, null, null);
				//map draw
				map.Draw(mainGame.spriteBatch);
				//ParticleEngine
				particleEngine.Draw(gameTime);
				//buildMode draw
				buildMode.Draw(mainGame.spriteBatch);
				//Draw scene
				base.Draw(gameTime);
				//Character
				myCharacter.Draw(mainGame.spriteBatch);
				//SpellManager
				spellManager.Draw(mainGame.spriteBatch);
				mainGame.spriteBatch.End();

				if (shaderActivated) {
					lightShaderManager.Draw(mainTarget, camera); //Shader
				} else {
					mainGame.GraphicsDevice.SetRenderTarget(null);
					mainGame.spriteBatch.Begin(SpriteSortMode.Immediate, null, SamplerState.PointClamp, null, 
					                           null, null, camera.Transform);
					mainGame.spriteBatch.Draw(mainTarget, Vector2.Zero, Color.White);
					mainGame.spriteBatch.End();
				}

				mainGame.spriteBatch.Begin();
				gameplayOutput.Draw(mainGame.spriteBatch); //GUI
				mainGame.spriteBatch.End();

				Fps_Count = Math.Floor(1.0f / (float)gameTime.ElapsedGameTime.TotalSeconds);
			}
		}

		//SHADER
		public void ShaderSet(bool activated)
		{
			//Shader
			var pp = mainGame.GraphicsDevice.PresentationParameters;
			mainTarget = new RenderTarget2D(mainGame.GraphicsDevice, TileMap.MapWidth * TileMap.TileWidth,
			                                TileMap.MapHeight * TileMap.TileHeight);

			lightShaderManager = new LightShader(mainGame);

			if (activated) {
				lightShaderManager.AmbientColor(timeManager.BackgroundValue);
				lightShaderManager.Load();
				shaderActivated = true;
			} else {
				shaderActivated = false;
			}
		}

		//GET INFO BY THE MAP
		public void TileObjectRecup()
		{
			//Recup map tileObject
			TileObjectList = new List<TileObject>();

			for (int i = 0; i < map.TileObjectIndex.Count; i++) {
				int gid = TileMap.lstLayer[1][map.TileObjectIndex[i]].Gid;
				if (gid == 21) {
					TileObjectList.Add(new Crop(map.TileObjectIndex[i], CropData.Data["WHEAT"], 0));
				} else if (gid == 22) {
					TileObjectList.Add(new Crop(map.TileObjectIndex[i], CropData.Data["WHEAT"], 1));
				} else if (gid == 23) {
					TileObjectList.Add(new Crop(map.TileObjectIndex[i], CropData.Data["WHEAT"], 2));
				} else if (gid == 25) {
					int index = map.TileObjectIndex[i];
					Vector2 Position = new Vector2(index - (Math.Abs(index / TileMap.MapWidth) * TileMap.MapWidth),
												   Math.Abs(index / TileMap.MapWidth));
					Position = new Vector2(Position.X * TileMap.TileWidth + TileMap.TileWidth / 2,
										   Position.Y * TileMap.TileHeight + TileMap.TileHeight / 2); //centred
					lightShaderManager.AddLightShader(Position, Color.Yellow);
				}
			}
		}

		private void DryGround()
		{
			for (int i = 0; i < TileMap.lstLayer[0].Count; i++) {
				if (util.getTileType(TileMap.lstLayer[0][i].Gid) == "farmLandWet") {
					TileMap.lstLayer[0][i].Gid = util.getTileId("farmLand");
				}
			}
		}
	}
}