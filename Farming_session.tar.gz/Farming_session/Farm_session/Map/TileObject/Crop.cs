﻿using System;
using System.Collections.Generic;
using Microsoft.Xna.Framework;

namespace Farming_session
{
	public class Crop : TileObject
	{
		//Crop
		public int currentState;
		public List<int> lstTileId;
		public List<int> lstStateTime;
		private float timer;
		private int stateTime;
		public int maxState;

		public Crop()
		{

		}

		public Crop(int pIndex, Crop pCopy, int pState = 0) : base(pIndex)
		{
			Type = eType.Crop;

			currentState = pState;
			TileId = pCopy.lstTileId[pState];

			lstTileId = pCopy.lstTileId;
			lstStateTime = pCopy.lstStateTime;

			maxState = lstTileId.Count - 1;

			Load();
		}

		private void Load()
		{
			//TileObject
			Position = new Vector2(Index - (Math.Abs(Index / TileMap.MapWidth) * TileMap.MapWidth),
								   Math.Abs(Index / TileMap.MapWidth));
			Position = new Vector2(Position.X * TileMap.TileWidth, Position.Y * TileMap.TileHeight);
			Delete = false;

			//Crop
			timer = 0;
			stateTime = getRandomTime(lstStateTime[currentState]);

			TileMap.lstLayer[1][Index].Gid = lstTileId[currentState];
		}

		private int getRandomTime(int time)
		{
			time *= 100;
			float pMin = time - (time / 100 * 20);
			float pMax = time + (time / 100 * 20);
			time = util.getInt((int)pMin, (int)pMax) / 100;
			//Console.WriteLine(time);
			return time;
		}

		public void Update(GameTime gameTime)
		{
			if (util.getTileType(TileMap.lstLayer[0][Index].Gid) == "farmLandWet") {
				if (currentState < maxState) {
					timer += (float)gameTime.ElapsedGameTime.TotalSeconds;
					if (timer >= stateTime) {
						stateTime = getRandomTime(lstStateTime[currentState]);
						timer = 0;
						currentState++;

						TileMap.lstLayer[1][Index].Gid = lstTileId[currentState];
					}
				} else {
					TileMap.lstLayer[0][Index].Gid = util.getTileId("farmLand");
					Delete = true;
				}
			}
		}
	}
}
