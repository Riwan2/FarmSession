﻿using System;
using System.Collections.Generic;
using Microsoft.Xna.Framework;

namespace Farming_session
{
	public class ChangeMap
	{
		private SceneGameplay scene;
		private MainGame mainGame;

		public Map CurrentMap;

		public ChangeMap(SceneGameplay pSceneGameplay, MainGame pMainGame, Map pCurrentMap)
		{
			scene = pSceneGameplay;
			mainGame = pMainGame;
			CurrentMap = pCurrentMap;
		}

		public void Change(string newMap)
		{
			bool savingMap = false;

			if (MapData.Data.ContainsKey(newMap)) {
				Map map = new Map(MapData.Data[newMap]);
				Map lastMap = scene.changeMap.CurrentMap;
				scene.changeMap.CurrentMap = map;
				//Character
				scene.myCharacter.Position = map.HeroPosition;
				while (!savingMap) {
					if (lastMap.IsSave) {
						scene.mapFile.SavingMap();
					}
					savingMap = true;
				}
				scene.map = new TileMap(mainGame, map.FileName);
				scene.map.LoadMap();

				scene.gameFile.SavingGameData();
				//Shader
				scene.ShaderSet(map.IsShader);
				//TileObject
				scene.TileObjectRecup();
				//Camera
				scene.camera.CameraFix = map.CameraFix;
				if (map.CameraFix) {
					scene.camera.Position = map.CameraPosition;
					Console.WriteLine("cameraPosition");
				} else {
					Vector2 posCamera = scene.myCharacter.Position;
					posCamera = new Vector2(-MainGame.ScreenWidth, -MainGame.ScreenHeight);
					scene.camera.Position = posCamera;
					Console.WriteLine("playerposititon");
				}
			}
		}
	}
}
