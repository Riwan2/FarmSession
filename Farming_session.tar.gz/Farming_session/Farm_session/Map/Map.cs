﻿using System;
using System.Collections.Generic;
using Microsoft.Xna.Framework;

namespace Farming_session
{
	public class Map
	{
		public Vector2 HeroPosition;
		public Vector2 CameraPosition;
		public string FileName;
		public bool IsShader;
		public bool IsSave;
		public bool CameraFix;

		public Map()
		{

		}

		public Map(Map pCopy)
		{
			HeroPosition = pCopy.HeroPosition;
			FileName = pCopy.FileName;
			IsShader = pCopy.IsShader;
			IsSave = pCopy.IsSave;
			CameraFix = pCopy.CameraFix;
			CameraPosition = pCopy.CameraPosition;
		}
	}

	public static class MapData
	{
		public static Dictionary<string, Map> Data;

		public static void PopulateData()
		{
			Data = new Dictionary<string, Map>();

			Data.Add("house", new Map {
				FileName = "house", HeroPosition = new Vector2(MainGame.ScreenWidth / 6.83f,
														   MainGame.ScreenHeight / 2.05f),
				IsSave = false, IsShader = false, CameraFix = true, 
				CameraPosition = new Vector2(-MainGame.ScreenWidth / 1.6f, -MainGame.ScreenHeight / 1.2f) });

			Data.Add("PlayerLevel", new Map {
				FileName = "PlayerLevel", HeroPosition = new Vector2(MainGame.ScreenWidth / 3.19f,
																 MainGame.ScreenHeight / 4),
				IsSave = true, IsShader = true, CameraFix = false, });
		}
	}
}
