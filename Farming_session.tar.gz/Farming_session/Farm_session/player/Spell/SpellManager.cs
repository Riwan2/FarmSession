﻿using System;
using System.Collections.Generic;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace Farming_session
{
	public class SpellManager
	{
		public List<PassivSpell> lstPassivSpell;

		public SpellManager()
		{
			lstPassivSpell = new List<PassivSpell>();
		}

		public void AddPassivSpell(PassivSpell spell)
		{
			lstPassivSpell.Add(spell);
		}

		public void Update(GameTime gameTime)
		{
			for (int i = 0; i < lstPassivSpell.Count; i++) {
				if (lstPassivSpell[i].Dead) {
					lstPassivSpell.RemoveAt(i);
				} else {
					lstPassivSpell[i].Update(gameTime);
				}
			}
		}

		public void Draw(SpriteBatch spriteBatch)
		{
			for (int i = 0; i < lstPassivSpell.Count; i++) {
				lstPassivSpell[i].Draw(spriteBatch);
			}
		}
	}
}
