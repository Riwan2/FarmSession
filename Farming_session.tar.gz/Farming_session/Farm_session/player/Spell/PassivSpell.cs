﻿using System;
using System.Collections.Generic;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;

namespace Farming_session
{
	public class PassivSpell
	{
		public string DisplayName;
		public float duration;
		public Texture2D Texture;

		protected float timer;
		public bool Dead;

		public PassivSpell(string pDisplayName, float pDuration, Texture2D pTexture)
		{
			DisplayName = pDisplayName;
			duration = pDuration;
			Texture = pTexture;
			Dead = false;
		}

		public PassivSpell(PassivSpell pCopy)
		{
			DisplayName = pCopy.DisplayName;
			duration = pCopy.duration;
			Texture = pCopy.Texture;
		}

		public virtual void Update(GameTime gameTime)
		{

		}

		public virtual void Draw(SpriteBatch spriteBatch)
		{

		}
	}

	public static class PassivSpellData
	{
		public static Dictionary<string, PassivSpell> Data;

		public static void PopulateData(ContentManager content)
		{
			Data = new Dictionary<string, PassivSpell>();

			Data.Add("WATER_CROP", new PassivSpell("Water Crops", 4, 
			                                        content.Load<Texture2D>("Particle/SquareParticle")));
		}
	}
}
